use std::sync::{Arc, Mutex};

use native_api_1c::{
    native_api_1c_core::ffi::connection::Connection,
    native_api_1c_macro::AddIn,
};

use tantivy::{
    collector::TopDocs,
    doc,
    query::QueryParser,
    schema::{Field, Schema, Document, STORED, TEXT},
    Index,
};

struct SearchEngine {
    index: Option<Index>,
    text_field: Option<Field>,
    id_field: Option<Field>,
    extra_field: Option<Field>,
    total: usize,
}

impl Default for SearchEngine {
    fn default() -> Self {
        Self {
            index: None,
            text_field: None,
            id_field: None,
            extra_field: None,
            total: 0,
        }
    }
}

impl SearchEngine {
    fn search(&self, query: &str, limit: usize) -> Result<String, Box<dyn std::error::Error>> {
        let index = self
            .index
            .as_ref()
            .ok_or("Индекс не построен. Сначала вызовите ПостроитьИндекс().")?;
        let text_field = self.text_field.unwrap();
        let id_field = self.id_field.unwrap();
        let extra_field = self.extra_field.unwrap();

        let reader = index.reader()?;
        let searcher = reader.searcher();

        let parser = QueryParser::for_index(index, vec![text_field]);
        let q = parser.parse_query(query)?;

        let top = searcher.search(&q, &TopDocs::with_limit(limit.max(1)))?;

        let mut hits = Vec::new();
        for (score, addr) in top {
            let document = searcher.doc(addr)?;
            
            hits.push(serde_json::json!({
                "id": document.get_first(id_field).map(|v| v.as_text().unwrap_or("")).unwrap_or(""),
                "text": document.get_first(text_field).map(|v| v.as_text().unwrap_or("")).unwrap_or(""),
                "extra": document.get_first(extra_field).map(|v| v.as_text().unwrap_or("")).unwrap_or(""),
                "score": score,
            }));
        }

        Ok(serde_json::to_string(&hits)?)
    }

    fn build_index_from_docs(&mut self, docs: &[serde_json::Value]) -> Result<usize, Box<dyn std::error::Error>> {
        let mut schema_builder = Schema::builder();
        let id_field = schema_builder.add_text_field("id", STORED);
        let text_field = schema_builder.add_text_field("text", TEXT);
        let extra_field = schema_builder.add_text_field("extra", STORED);
        let schema = schema_builder.build();

        let index = Index::create_in_ram(schema);
        let mut writer = index.writer(50_000_000)?;

        for d in docs {
            let id = d.get("id").and_then(|v| v.as_str()).unwrap_or("");
            let text = d.get("text").and_then(|v| v.as_str()).unwrap_or("");
            let extra = d.get("extra").and_then(|v| v.as_str()).unwrap_or("");
            writer.add_document(doc!(
                id_field => id.to_string(),
                text_field => text.to_string(),
                extra_field => extra.to_string()
            ))?;
        }

        writer.commit()?;
        drop(writer);

        self.index = Some(index);
        self.text_field = Some(text_field);
        self.id_field = Some(id_field);
        self.extra_field = Some(extra_field);
        self.total = docs.len();

        Ok(docs.len())
    }

    fn parse_pipe_format(&self, data: &str) -> Vec<serde_json::Value> {
        let mut docs = Vec::new();
        for line in data.lines() {
            let trimmed = line.trim();
            if trimmed.is_empty() {
                continue;
            }
            
            let parts: Vec<&str> = trimmed.split('|').collect();
            if parts.len() >= 2 {
                let mut json_obj = serde_json::Map::new();
                json_obj.insert("id".to_string(), serde_json::Value::String(parts[0].trim().to_string()));
                json_obj.insert("text".to_string(), serde_json::Value::String(parts[1].trim().to_string()));
                
                if parts.len() >= 3 {
                    json_obj.insert("extra".to_string(), serde_json::Value::String(parts[2].trim().to_string()));
                } else {
                    json_obj.insert("extra".to_string(), serde_json::Value::String("".to_string()));
                }
                
                docs.push(serde_json::Value::Object(json_obj));
            }
        }
        docs
    }
}

#[derive(AddIn)]
pub struct NativeApiSearch {
    #[add_in_con]
    connection: Arc<Option<&'static Connection>>,

    engine: Arc<Mutex<SearchEngine>>,

    #[add_in_prop(name = "CollectionJson", name_ru = "КоллекцияJSON", readable, writable)]
    collection_json: String,
}

#[allow(dead_code)]
impl NativeApiSearch {
    pub fn new() -> Self {
        Self {
            connection: Arc::new(None),
            engine: Arc::new(Mutex::new(SearchEngine::default())),
            collection_json: String::new(),
        }
    }

    #[add_in_func(name = "BuildIndex", name_ru = "ПостроитьИндекс")]
    #[returns(Int, result)]
    pub fn build_index(&self) -> Result<i32, Box<dyn std::error::Error>> {
        let docs: Vec<serde_json::Value> = serde_json::from_str(&self.collection_json)
            .map_err(|e| -> Box<dyn std::error::Error> {
                format!("Ошибка разбора КоллекцияJSON: {}", e).into()
            })?;

        let mut engine = self.engine.lock().unwrap();
        let count = engine.build_index_from_docs(&docs)?;
        Ok(count as i32)
    }

    #[add_in_func(name = "Search", name_ru = "Поиск")]
    #[arg(Str)]
    #[arg(Int)]
    #[returns(Str, result)]
    pub fn search(&self, query: String, limit: i32) -> Result<String, Box<dyn std::error::Error>> {
        let engine = self.engine.lock().unwrap();
        engine.search(&query, limit as usize)
    }

    #[add_in_func(name = "Add", name_ru = "Добавить")]
    #[arg(Str)]
    #[arg(Str)]
    #[arg(Str)]
    #[returns(Int, result)]
    pub fn add(&self, id: String, text: String, extra: String) -> Result<i32, Box<dyn std::error::Error>> {
        let mut engine = self.engine.lock().unwrap();

        let index = engine
            .index
            .as_ref()
            .ok_or("Индекс не построен. Сначала вызовите ПостроитьИндекс().")?;
        let id_field = engine.id_field.unwrap();
        let text_field = engine.text_field.unwrap();
        let extra_field = engine.extra_field.unwrap();

        let mut writer = index.writer(50_000_000)?;
        writer.add_document(doc!(
            id_field => id,
            text_field => text,
            extra_field => extra
        ))?;
        writer.commit()?;
        drop(writer);

        engine.total += 1;
        Ok(1)
    }

    #[add_in_func(name = "Remove", name_ru = "Удалить")]
    #[arg(Str)]
    #[returns(Int, result)]
    pub fn remove(&self, id: String) -> Result<i32, Box<dyn std::error::Error>> {
        let mut engine = self.engine.lock().unwrap();

        let index = engine
            .index
            .as_ref()
            .ok_or("Индекс не построен. Сначала вызовите ПостроитьИндекс().")?;
        let id_field = engine.id_field.unwrap();

        let mut writer = index.writer(50_000_000)?;
        let term = tantivy::Term::from_field_text(id_field, &id);
        writer.delete_term(term);
        writer.commit()?;
        drop(writer);

        engine.total = engine.total.saturating_sub(1);
        Ok(1)
    }

    #[add_in_func(name = "Count", name_ru = "Количество")]
    #[returns(Int, result)]
    pub fn count(&self) -> Result<i32, Box<dyn std::error::Error>> {
        Ok(self.engine.lock().unwrap().total as i32)
    }

    #[add_in_func(name = "BuildIndexFromPipeFormat", name_ru = "ПостроитьИндексИзPipeФормата")]
    #[arg(Str)]
    #[returns(Int, result)]
    pub fn build_index_from_pipe_format(&self, data: String) -> Result<i32, Box<dyn std::error::Error>> {
        let engine = self.engine.lock().unwrap();
        let docs = engine.parse_pipe_format(&data);
        
        if docs.is_empty() {
            return Err("Нет данных для индексации".into());
        }
        
        drop(engine);
        let mut engine = self.engine.lock().unwrap();
        let count = engine.build_index_from_docs(&docs)?;
        Ok(count as i32)
    }

    #[add_in_func(name = "BuildIndexFrom1CArray", name_ru = "ПостроитьИндексИзМассива1С")]
    #[arg(Str)]
    #[returns(Int, result)]
    pub fn build_index_from_1c_array(&self, array_data: String) -> Result<i32, Box<dyn std::error::Error>> {
        let docs: Vec<serde_json::Value> = serde_json::from_str(&array_data)?;
        
        let mut engine = self.engine.lock().unwrap();
        let count = engine.build_index_from_docs(&docs)?;
        Ok(count as i32)
    }

    #[add_in_func(name = "ClearIndex", name_ru = "ОчиститьИндекс")]
    #[returns(Int, result)]
    pub fn clear_index(&self) -> Result<i32, Box<dyn std::error::Error>> {
        let mut engine = self.engine.lock().unwrap();
        *engine = SearchEngine::default();
        Ok(0)
    }

    #[add_in_func(name = "AddBatch", name_ru = "ДобавитьПакет")]
    #[arg(Str)]
    #[returns(Int, result)]
    pub fn add_batch(&self, batch_data: String) -> Result<i32, Box<dyn std::error::Error>> {
        let docs: Vec<serde_json::Value> = serde_json::from_str(&batch_data)?;
        let mut added = 0;
        
        for doc_json in docs {
            let id = doc_json.get("id").and_then(|v| v.as_str()).unwrap_or("");
            let text = doc_json.get("text").and_then(|v| v.as_str()).unwrap_or("");
            let extra = doc_json.get("extra").and_then(|v| v.as_str()).unwrap_or("");
            
            self.add(id.to_string(), text.to_string(), extra.to_string())?;
            added += 1;
        }
        
        Ok(added)
    }

    #[add_in_func(name = "GetAllDocuments", name_ru = "ПолучитьВсеДокументы")]
    #[returns(Str, result)]
    pub fn get_all_documents(&self) -> Result<String, Box<dyn std::error::Error>> {
        let engine = self.engine.lock().unwrap();
        
        let index = engine
            .index
            .as_ref()
            .ok_or("Индекс не построен")?;
            
        let reader = index.reader()?;
        let searcher = reader.searcher();
        
        let mut docs = Vec::new();
        let top = searcher.search(&tantivy::query::AllQuery, &TopDocs::with_limit(10000))?;
        
        for (_score, addr) in top {
            let doc = searcher.doc(addr)?;
            let id_field = engine.id_field.unwrap();
            let text_field = engine.text_field.unwrap();
            let extra_field = engine.extra_field.unwrap();
            
            docs.push(serde_json::json!({
                "id": doc.get_first(id_field).map(|v| v.as_text().unwrap_or("")).unwrap_or(""),
                "text": doc.get_first(text_field).map(|v| v.as_text().unwrap_or("")).unwrap_or(""),
                "extra": doc.get_first(extra_field).map(|v| v.as_text().unwrap_or("")).unwrap_or(""),
            }));
        }
        
        Ok(serde_json::to_string(&docs)?)
    }
}